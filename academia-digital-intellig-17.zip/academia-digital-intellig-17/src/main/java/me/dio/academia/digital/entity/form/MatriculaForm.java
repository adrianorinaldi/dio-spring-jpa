package me.dio.academia.digital.entity.form;

public class MatriculaForm {

  private Long alunoId;

}
